﻿using System;

namespace API.Models.User
{
    public class TokenManager
    {
        public string AuthToken { get; set; }

        public string TokenType { get; set; }

        public DateTime ExpiresIn { get; set; }
    }
}
