﻿using System.ComponentModel.DataAnnotations;

namespace API.Models.User
{
    public class RegisterVM
    {
        [Required]
        public string Name { get; set; }

        [Required, DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required, DataType(DataType.Password)]
        public string Password { get; set; }

    }
}
