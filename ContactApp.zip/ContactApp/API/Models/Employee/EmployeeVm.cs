﻿using System.ComponentModel.DataAnnotations;

namespace API.Models.Employee
{
    public class EmployeeVm
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required, DataType(DataType.EmailAddress)]
        public string Email { get; set; }
    }
}
