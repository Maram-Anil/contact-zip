﻿using API.Data;
using API.Models.User;
using API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly IConfiguration _config;

        public UsersController(ApplicationDbContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        [HttpPost, Route("login")]
        public async Task<ActionResult> GetUser(LoginVM loginVM)
        {
            if (!ModelState.IsValid)
            {
                return ValidationProblem(ModelState);
            }

            var user = await _context.Users.SingleOrDefaultAsync(e => e.Email.Equals(loginVM.Email));

            if (user == null)
            {
                return NotFound("Email not found in system.");
            }

            if (user.Password != loginVM.Password.Encrypt())
            {
                return NotFound("Email/password are not correct.");
            }

            return Ok(GenerateTokenAsync(user));
        }

        [HttpPost, Route("register")]
        public async Task<ActionResult> PostUser(RegisterVM user)
        {
            if (!ModelState.IsValid)
            {
                return ValidationProblem(ModelState);
            }

            if (UserExists(user.Email))
            {
                return BadRequest("Email already exists in system.");
            }

            _context.Users.Add(new User
            {
                Name = user.Name,
                Email = user.Email,
                Password = user.Password.Encrypt(),
                CreatedOn = DateTime.Now,
                CreatedBy = "System"
            });

            await _context.SaveChangesAsync();

            return Ok("User Created successfully");
        }

        private bool UserExists(int id)
        {
            return _context.Users.Any(e => e.Id == id);
        }

        private bool UserExists(string email)
        {
            return _context.Users.Any(e => e.Email == email);
        }

        private TokenManager GenerateTokenAsync(User user)
        {
            var _key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["TokenKey"]));

            DateTime expire = DateTime.Now.AddDays(7);

            var tokenManager = new TokenManager() { TokenType = "bearer", ExpiresIn = expire };

            var claims = new List<Claim>
           {
               new Claim(JwtRegisteredClaimNames.NameId,user.Id.ToString()),
               new Claim(JwtRegisteredClaimNames.Email,user.Email),
               new Claim(JwtRegisteredClaimNames.Name,user.Name),
           };

            var creds = new SigningCredentials(_key, SecurityAlgorithms.HmacSha512Signature);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = expire,
                SigningCredentials = creds,
            };

            var tokenHandler = new JwtSecurityTokenHandler();

            var token = tokenHandler.CreateToken(tokenDescriptor);

            tokenManager.AuthToken = tokenHandler.WriteToken(token);

            return tokenManager;
        }
    }
}
