﻿using System.Text;
using System;

namespace API.Services
{
    public static class Protector
    {
        public static string Encrypt(this string plainText)
        {
            byte[] b = Encoding.ASCII.GetBytes(plainText);
            return Convert.ToBase64String(b);
        }

        public static string Decrypt(this string encryptText)
        {
            byte[] b = Convert.FromBase64String(encryptText);
            return Encoding.ASCII.GetString(b);
        }
    }
}
